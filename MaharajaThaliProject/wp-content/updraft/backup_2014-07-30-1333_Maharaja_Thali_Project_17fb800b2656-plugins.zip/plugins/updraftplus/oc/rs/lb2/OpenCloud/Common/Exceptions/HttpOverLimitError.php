<?php

namespace OpenCloud\Common\Exceptions;

class HttpOverLimitError extends \Exception {}
