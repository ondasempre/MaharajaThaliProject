<?php

namespace OpenCloud\Common\Exceptions;

class DatabaseCreateError extends \Exception {}
