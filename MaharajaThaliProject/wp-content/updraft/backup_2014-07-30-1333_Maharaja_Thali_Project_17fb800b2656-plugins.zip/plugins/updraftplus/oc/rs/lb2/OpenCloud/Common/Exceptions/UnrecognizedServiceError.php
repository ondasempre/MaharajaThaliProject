<?php

namespace OpenCloud\Common\Exceptions;

class UnrecognizedServiceError extends \Exception {}
