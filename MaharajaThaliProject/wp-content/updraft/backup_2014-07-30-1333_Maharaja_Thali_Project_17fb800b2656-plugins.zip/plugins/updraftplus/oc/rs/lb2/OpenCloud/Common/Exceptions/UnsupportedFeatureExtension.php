<?php

namespace OpenCloud\Common\Exceptions;

class UnsupportedFeatureExtension extends \Exception {}
