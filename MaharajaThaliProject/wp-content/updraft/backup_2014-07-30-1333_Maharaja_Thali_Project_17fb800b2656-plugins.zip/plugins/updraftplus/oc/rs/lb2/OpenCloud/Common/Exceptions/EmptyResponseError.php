<?php

namespace OpenCloud\Common\Exceptions;

class EmptyResponseError extends \Exception {}
