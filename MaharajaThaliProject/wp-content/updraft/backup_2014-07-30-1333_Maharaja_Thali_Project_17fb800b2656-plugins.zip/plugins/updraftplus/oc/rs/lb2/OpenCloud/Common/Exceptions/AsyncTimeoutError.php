<?php

namespace OpenCloud\Common\Exceptions;

class AsyncTimeoutError extends \Exception {}
