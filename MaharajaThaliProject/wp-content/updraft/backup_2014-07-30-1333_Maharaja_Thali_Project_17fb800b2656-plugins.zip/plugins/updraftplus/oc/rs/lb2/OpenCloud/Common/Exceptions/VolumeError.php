<?php

namespace OpenCloud\Common\Exceptions;

class VolumeError extends \Exception {}
