<?php

namespace OpenCloud\Common\Exceptions;

class ServerImageScheduleError extends \Exception {}
